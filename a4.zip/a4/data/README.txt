From http://www9.informatik.uni-erlangen.de/External/vollib/
