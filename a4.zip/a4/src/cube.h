// cube.h


#ifndef CUBE_H
#define CUBE_H

void renderCubeOutline();
void renderCubeWithRGBCoords();

#endif
