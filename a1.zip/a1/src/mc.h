// mc.h

extern bool pauseGame;
