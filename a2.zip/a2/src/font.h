// font.h
 
void initFont( char *ttf_file, int height_in_pixels );
void render_text( const char *text, int pixOriginX, int pixOriginY, GLFWwindow* window );
