// toon.h

#ifndef SHADER_H
#define SHADER_H


extern GLuint windowWidth, windowHeight;
extern float factor;

#endif
