Compile with 'make'.

Execute as './toon ../data/teapot.obj'.

See the Makefile if you want to have text on the screen.
